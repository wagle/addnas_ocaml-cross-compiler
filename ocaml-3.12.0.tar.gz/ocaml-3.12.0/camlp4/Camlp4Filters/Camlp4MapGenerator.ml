(* This module is useless now. Camlp4FoldGenerator handles map too. *)
module Id = struct
  value name    = "Camlp4MapGenerator";
  value version = Sys.ocaml_version;
end;
