type t1 = <:power< 6 | int >>
type t2 = <:power< 3 | int -> int >> -> int
type t3 = <:power< 3 | int -> <:power< 2 | int >> >> -> int
